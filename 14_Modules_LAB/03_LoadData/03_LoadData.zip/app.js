let functions = require('./template');

result.sort = functions.sort;
result.filter = functions.filter;